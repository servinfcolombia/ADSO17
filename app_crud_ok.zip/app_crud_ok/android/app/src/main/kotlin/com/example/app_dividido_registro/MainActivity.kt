package com.example.app_dividido_registro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
